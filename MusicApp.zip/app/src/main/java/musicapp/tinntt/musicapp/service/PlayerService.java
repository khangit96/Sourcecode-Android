package musicapp.tinntt.musicapp.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.os.Looper;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Objects;
import java.util.logging.Handler;

import musicapp.tinntt.musicapp.R;

public class PlayerService extends Service {

    Thread t;
    android.os.Handler h;
    MediaPlayer mediaPlayer;
    String url;
    String name;
    UpdateTimerRunable updateTimerRunable;
    NotificationManager notificationManager;
    BroadcastReceiver notificationReceiver;

    public PlayerService() {

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        url = intent.getStringExtra("songURL");
        name = intent.getStringExtra("songName");
        playAudio();
        showNotification();
        IntentFilter filter = new IntentFilter("ChangeStatusMedia");
        filter.addAction("SeekChange");
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver(), filter);

        return super.onStartCommand(intent, flags, startId);
    }

    private void showNotification() {
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        notificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (intent.getAction()) {
                    case "changeStatus":
                        if (mediaPlayer.isPlaying()) {
                            mediaPlayer.pause();
                            updateTimerRunable.onPause();
                        } else {
                            mediaPlayer.start();
                            updateTimerRunable.onResume();
                        }
                        break;
                    case "stopAudio":
                        mediaPlayer.pause();
                        updateTimerRunable.onPause();
                        notificationManager.cancelAll();
                        stopSelf();
                        break;
                }
            }
        };

        IntentFilter intentFilter = new IntentFilter("changeStatus");
        intentFilter.addAction("stopAudio");
        registerReceiver(notificationReceiver, intentFilter);

        PendingIntent changeStatusIntent = PendingIntent.getBroadcast(this, 0, new Intent("changeStatus"), PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stopAudioIntent = PendingIntent.getBroadcast(this, 0, new Intent("stopAudio"), PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new NotificationCompat.Builder(this)
                .setContentTitle("Audio Player")
                .setContentText(name)
                .addAction(R.drawable.ic_very_small, "pause/resume", changeStatusIntent)
                .addAction(R.drawable.ic_very_small, "stop", stopAudioIntent)
                .setSmallIcon(R.drawable.ic_small).build();

        notification.flags |= Notification.FLAG_ONGOING_EVENT;
//        notificationManager.notify(1, notification);
        startForeground(1, notification);
    }

    private BroadcastReceiver receiver() {
        return new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (intent.getAction()) {
                    case "ChangeStatusMedia":
                        if (mediaPlayer.isPlaying()) {
                            mediaPlayer.pause();
                            updateTimerRunable.onPause();
                        } else {
                            mediaPlayer.start();
                            updateTimerRunable.onResume();
                        }
                        break;
                    case "SeekChange":
                        int currentPosition = intent.getIntExtra("currentPosition", 0);
                        mediaPlayer.seekTo(currentPosition * mediaPlayer.getDuration() / 100);
                        break;
                }
            }
        };
    }

    private void sendDurationToActivity(int duration) {
        Intent i = new Intent("SendDuration");

        i.putExtra("duration", duration);

        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
    }

    private void sendProgressToActivity(int progress, int currentPosition) {
        Intent i = new Intent("SendProgress");

        i.putExtra("progress", progress);
        i.putExtra("currentPosition", currentPosition);

        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
    }

    class UpdateTimerRunable implements Runnable {

        private Object pauseLock;
        private boolean isPause;

        public UpdateTimerRunable() {
            isPause = false;
            pauseLock = new Object();
        }

        @Override
        public void run() {
            while (mediaPlayer.isPlaying()) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                sendProgressToActivity(mediaPlayer.getCurrentPosition() * 100 / mediaPlayer.getDuration(), mediaPlayer.getCurrentPosition());
                synchronized (pauseLock) {
                    while (isPause) {
                        try {
                            pauseLock.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        public void onPause() {
            synchronized (pauseLock) {
                isPause = true;
            }
        }

        public void onResume() {
            synchronized (pauseLock) {
                isPause = false;
                pauseLock.notifyAll();
            }
        }

    }

    private void createUpdateTimer() {
        updateTimerRunable = new UpdateTimerRunable();
        new Thread(updateTimerRunable).start();
    }

    private void playAudio() {
        if (h == null) {
            t = new Thread(new Runnable() {
                @Override
                public void run() {
                    Looper.prepare();
                    h = new android.os.Handler();
                    File f = new File(url);
                    if (f.exists() && f.isFile()) {
                        h.post(playAudioFromFile());
                    } else {
                        h.post(playAudioFromUrl());
                    }
                    Looper.loop();
                }
            });
            t.start();
        } else {
            File f = new File(url);
            if (f.exists() && f.isFile()) {
                h.post(playAudioFromFile());
            } else {
                h.post(playAudioFromUrl());
            }
        }
    }

    private Runnable playAudioFromFile() {
        return new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }
                mediaPlayer = new MediaPlayer();
                File f = new File(url);
                if (!f.exists()) {
                    stopSelf();
                    return;
                }

                try {
                    mediaPlayer.setDataSource(f.getPath());
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            sendDurationToActivity(mediaPlayer.getDuration());
                            createUpdateTimer();
                        }
                    });
                    mediaPlayer.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            }
        };

    }

    private Runnable playAudioFromUrl() {
        return new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }
                String path = getExternalCacheDir() + "/.Audio/";
                File folder = new File(path);
                if(!folder.exists()){
                    folder.mkdir();
                }
                File f = new File(getExternalCacheDir() + "/.Audio/" + String.valueOf(url.hashCode()) + ".mp3");
                if(!f.exists()){
                    try {
                        f.createNewFile();
                        InputStream in = new URL(url).openStream();
                        BufferedInputStream bis = new BufferedInputStream(in);
                        FileOutputStream fos = new FileOutputStream(f);
                        BufferedOutputStream bos = new BufferedOutputStream(fos);

                        do{
                            int byteOfFile = bis.read();
                            if(byteOfFile == -1)
                                break;

                            bos.write(byteOfFile);
                        }while (true);

                        bos.close();
                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }

                mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(f.getPath());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            sendDurationToActivity(mediaPlayer.getDuration());
                            createUpdateTimer();
                        }
                    });
                    mediaPlayer.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            }
        };
    }


    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
