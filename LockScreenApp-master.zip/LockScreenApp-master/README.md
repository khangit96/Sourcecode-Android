LockScreenApp
=============


Features:
- Lockscreen over the screen
- Hardware home button disabled
- On-going notification to prevent app being killed by OS

It provides lockscreen in API 8 or above.

Initial

![Alt text](http://thumbnails114.imagebam.com/42319/f1a34d423182524.jpg "")


Locked

![Alt text](http://thumbnails114.imagebam.com/42319/422e11423182518.jpg "")



Unlocked

![Alt text](http://thumbnails114.imagebam.com/42319/f1a34d423182524.jpg "")



