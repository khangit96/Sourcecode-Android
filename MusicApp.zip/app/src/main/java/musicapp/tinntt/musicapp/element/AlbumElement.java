package musicapp.tinntt.musicapp.element;

import android.content.Context;
import android.view.View;

import musicapp.tinntt.musicapp.R;

/**
 * Created by tikier on 1/11/16.
 */
public class AlbumElement extends BaseListElement {

    public AlbumElement(Context context){
        this.context = context;
        updateData();
    }

    @Override
    public void updateData() {
        this.setNumber(0);
        this.setElementName("Album");
        this.setIconResource(R.drawable.ic_default);
    }

    @Override
    public View.OnClickListener getOnClickListener() {
        return null;
    }
}
