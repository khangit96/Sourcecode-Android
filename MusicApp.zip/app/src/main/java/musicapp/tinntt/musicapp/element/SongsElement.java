package musicapp.tinntt.musicapp.element;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import musicapp.tinntt.musicapp.R;
import musicapp.tinntt.musicapp.activity.ListSongActivity;
import musicapp.tinntt.musicapp.util.StorageUtil;

/**
 * Created by tikier on 1/11/16.
 */
public class SongsElement extends BaseListElement {

    public static String OFF_SONG = "off_song";

    public SongsElement(Context context){
        this.context = context;
        updateData();
    }

    @Override
    public void updateData() {
        this.setElementName("Songs");
        this.setIconResource(R.drawable.ic_search_white);
        this.setNumber(StorageUtil.getMp3FileCursor(this.context).getCount());
    }

    @Override
    public View.OnClickListener getOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SongsElement.this.context, ListSongActivity.class);
                i.setAction(OFF_SONG);
                SongsElement.this.context.startActivity(i);
            }
        };
    }
}
