Simple-Lockscreen
=================

A simple lockscreen app for Android 4.0.3 or higher.  Used for instructional purposes
