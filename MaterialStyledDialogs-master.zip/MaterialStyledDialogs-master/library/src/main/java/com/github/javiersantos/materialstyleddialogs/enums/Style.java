package com.github.javiersantos.materialstyleddialogs.enums;

public enum Style {
    STYLE_HEADER
}
