package musicapp.tinntt.musicapp.util;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;

/**
 * Created by tikier on 1/15/16.
 */
public class StorageUtil {

    public static Cursor getMp3FileCursor(Context context) {

        ContentResolver cr = context.getContentResolver();

        Uri uri = MediaStore.Files.getContentUri("external");

        String selection = MediaStore.Files.FileColumns.MIME_TYPE + "=?";

        String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp3");

        String[] selectionArgsMp3 = new String[]{mimeType};

        return cr.query(uri, null, selection, selectionArgsMp3, null);
    }

}
